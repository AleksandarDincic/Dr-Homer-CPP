#include <iostream>
#include <string>
#include "Menu.h"




int main() {
	Menu::initialize();
	Menu m;
	m.start();

	return 0;
}