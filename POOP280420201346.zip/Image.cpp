#include <regex>
#include "Image.h"
#include "BMPFormatter.h"
#include "Selection.h"
#include "Exceptions.h"

Image* Image::image = nullptr;

Pixel Image::getPixel(int width, int height)
{
	int  tempRed = 0, tempGreen = 0, tempBlue = 0;
	double tempAlpha = 0;
	for (Layer *l : layers) {
		if (l->getVisible()) {
			double opacity = l->getOpacity() / 100.0;
			Pixel tempPixel = (*l)[height][width];
			double doubleA = tempPixel.getA() * opacity / 255.0;
			tempAlpha += (1 - tempAlpha) * doubleA;
		}
	}
	double temperAlpha = 0;
	for (Layer *l : layers) {
		if (l->getVisible()) {
			double opacity = l->getOpacity() / 100.0;
			Pixel tempPixel = (*l)[height][width];
			double doubleA = tempPixel.getA() * opacity / 255.0;
			tempRed += (1 - temperAlpha) * doubleA / tempAlpha * tempPixel.getR();
			tempGreen += (1 - temperAlpha) * doubleA / tempAlpha * tempPixel.getG();
			tempBlue += (1 - temperAlpha) * doubleA / tempAlpha * tempPixel.getB();
			temperAlpha += (1 - temperAlpha) * doubleA;
		}
	}
	return Pixel(tempRed, tempGreen, tempBlue, tempAlpha*255);
}

void Image::resize(Layer *l)
{
	if (height < l->getHeight() || width < l->getWidth()) {
		for (Layer *ll : layers) {
			ll->resize(width < l->getWidth() ? l->getWidth() : -1, height < l->getHeight() ? l->getHeight() : -1);
		}
		height = height < l->getHeight() ? l->getHeight() : height;
		width = width < l->getWidth() ? l->getWidth() : width;
	}
	l->resize(width > l->getWidth() ? width : -1, height > l->getHeight() ? height : -1);
}

Image * Image::getImage() {
	if (image == nullptr)
		image = new Image();
	return image;
}

void Image::setLayerOpacity(int pos, int opacity)
{
	if (layers.size() == 0 || pos < 0 || pos > layers.size() - 1)
		throw BadInputException("Layer index out of bounds");
	getLayer(pos).setOpacity(opacity);
}

void Image::setLayerActive(int pos, bool active)
{
	if (layers.size() == 0 || pos < 0 || pos > layers.size() - 1)
		throw BadInputException("Layer index out of bounds");
	getLayer(pos).setActive(active);
}

void Image::setLayerVisible(int pos, bool visible)
{
	if (layers.size() == 0 || pos < 0 || pos > layers.size() - 1)
		throw BadInputException("Layer index out of bounds");
	getLayer(pos).setVisible(visible);
}

void Image::setSelectionActive(const std::string& name, bool active)
{
	if (selections.find(name) != selections.end()) {
		selections[name]->setActive(active);
	}
	else throw BadInputException("Selection with that name doesn't exist");
}

void Image::addLayer(int width, int height)
{
	if (width <= 0 || height <= 0) throw BadInputException("Layer dimensions must be positive");
	Layer *tempLayer = new Layer(width, height);
	resize(tempLayer);
	layers.insert(layers.begin(), tempLayer);
}

void Image::addLayer(std::string path) {
	Formatter* reader;

	std::regex rx("[^\.]*\.(.*)");
	std::smatch extensionMatch;
	if (std::regex_match(path, extensionMatch, rx)) {
		std::string extension = extensionMatch.str(1);
		if ((reader = Formatter::getFormatter(extension)) && reader->getType() == Formatter::IMAGE) {
			Layer *tempLayer = reader->load(path);
			resize(tempLayer);
			layers.insert(layers.begin(), tempLayer);
		}
		else throw BadFormatException("Not an image format");
	}
}

void Image::addSelection(std::vector<Rectangle>& rects, std::string name)
{
	if (selections.find(name) == selections.end()) {
		selections[name] = new Selection(rects);
	}
	else throw BadInputException("Selection with that name already exists");
	//BACI IZUZETAK
}

void Image::operate()
{
	for (Layer *l : layers)
		if (l->getActive()) {
			for (Operation *o : operations)
				o->operateLayer(l, selections);
			l->clamp();
		}
}

void Image::deleteLayer(int pos)
{
	if (layers.size() == 0 || pos < 0 || pos > layers.size() - 1) 
		throw BadInputException("Layer index out of bounds");
	Layer *tempLayer = layers[pos];
	layers.erase(layers.begin() + pos);
	delete tempLayer;
}

void Image::deleteSelection(const std::string & name)
{
	if (selections.find(name) != selections.end()) {
		selections.erase(name);
	}
	else throw BadInputException("Selection with that name doesn't exist");
}

void Image::Export(std::string path)
{
	Formatter* writer;

	std::regex rx("[^\.]*\.(.*)");
	std::smatch extensionMatch;
	if (std::regex_match(path, extensionMatch, rx)) {
		std::string extension = extensionMatch.str(1);
		if ((writer = Formatter::getFormatter(extension)) 
			&& (writer->getType() == Formatter::IMAGE || writer->getType() == Formatter::PROJECT)) {
			writer->save(path);
		}
	}
	unsaved = false;
}

std::ostream & operator<<(std::ostream & o, const Image & i)
{
	o << "IMAGE:" << std::endl;
	o << "Size: " << i.width << 'x' << i.height << std::endl;
	o << "Layers:" << std::endl;
	int counter = 1;
	for (Layer *l : i.layers)
		o << counter++ << ". - " << *l << std::endl;
	//ovde layeri
	o << "Selections:" << std::endl;
	for (std::pair<std::string,Selection*> s : i.selections) {
		o << s.first << " - " << *(s.second) << std::endl;
	}
	//ovde selekcije
	o << "Operations:" << std::endl;
	for (Operation * op : i.operations) {
		o << op->getName() << " -> ";
	}
	//ovde operacije
	return o;
}
