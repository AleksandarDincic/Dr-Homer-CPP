#pragma once
#include <map>
#include "Layer.h"

class Formatter {
public:
	enum fileType {IMAGE, PROJECT, FUNCTION};

private:
	static std::map<std::string, Formatter*> formatMap;

public:
	static void addFormat(std::string fileType, Formatter *formatter);
	static Formatter* getFormatter(std::string fileType);

	virtual fileType getType() const = 0;
	virtual Layer* load(std::string path)const = 0;
	virtual void save(std::string path) const = 0;

};