#include "Layer.h"
#include <iostream>

void Layer::resize(int width, int height)
{
	if (width > 0) {
		for (std::vector<Pixel>& rows : pixels) {
			rows.resize(width, Pixel());
		}
	}
	if (height > 0) {
		pixels.resize(height, std::vector<Pixel>(getWidth(), Pixel()));
	}
}

void Layer::clamp()
{
	int height = getHeight();
	int width = getWidth();
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			(*this)[i][j].clamp();
		}
	}
}

std::ostream & operator<<(std::ostream & os, const Layer & l)
{
	return os << (l.getActive() ? "Active - " : "Inactive - ") << (l.getVisible() ? "Visible - " : "Invisible - ") << "Opacity " << l.opacity;
}
