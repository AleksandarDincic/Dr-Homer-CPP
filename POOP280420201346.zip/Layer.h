#pragma once
#include <vector>
#include "Pixel.h"
class Layer {
private:
	std::vector<std::vector<Pixel>> pixels;
	int opacity;
	bool active, visible;
public:
	Layer(int width, int height) :
		pixels(height, std::vector <Pixel>(width, Pixel())), opacity(100), active(false), visible(true) {}
	void resize(int width = -1, int height = -1);

	bool getActive() const { return active; }
	bool getVisible() const { return visible; }
	int getOpacity() const { return opacity; }
	int getHeight() const { return pixels.size(); }
	int getWidth() const { return pixels[0].size(); }

	void setActive(bool active) { this->active = active; }
	void setVisible(bool visible) { this->visible = visible; }
	void setOpacity(int opacity) { this->opacity = opacity >= 100 ? 100 : (opacity <= 0 ? 0 : opacity); }

	void clamp();

	std::vector<Pixel>& operator[](int i) { return pixels[i]; }
	friend std::ostream& operator<<(std::ostream& os, const Layer& l);
};