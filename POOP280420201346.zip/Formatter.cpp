#include "Formatter.h"

std::map<std::string, Formatter*> Formatter::formatMap;


void Formatter::addFormat(std::string fileType, Formatter * formatter)
{
	if (formatMap.find(fileType) == formatMap.end()) {
		formatMap[fileType] = formatter;
	}
	// u suprotnom exception
}

Formatter * Formatter::getFormatter(std::string fileType)
{
	if (formatMap.find(fileType) != formatMap.end())
		return formatMap[fileType];
	return nullptr;
}
