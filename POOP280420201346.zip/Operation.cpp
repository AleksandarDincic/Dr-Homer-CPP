#include <vector>
#include <iostream>
#include <cmath>
#include "Image.h"
#include "Operation.h"
#include "Exceptions.h"

std::map<std::string, Operation*> Operation::operationMap;

void BasicOperation::operateLayer(Layer * l, const std::map<std::string, Selection*>& s) const
{
	int width = l->getWidth();
	int height = l->getHeight();
	Layer *argumentLayer = aware() ? new Layer(*l) : l;
	for (int i = 0; i < height; i++)
		for (int j = 0; j < width; j++)
			if (!s.size() || std::any_of(s.cbegin(), s.cend(),
				[i, j](std::pair<std::string, Selection*> p)
			{ return p.second->getActive() && p.second->inSelection(j, i); })) {
				(*l)[i][j] = operatePixel(argumentLayer, j, i);
			}
	if (aware()) delete argumentLayer;
}

Pixel Add::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	return Pixel(tempPixel.getR() + paramR, tempPixel.getG() + paramG,
		tempPixel.getB() + paramB, tempPixel.getA());
}

void Add::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramB = params[2];
}

Pixel Sub::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	return Pixel(tempPixel.getR() - paramR, tempPixel.getG() - paramG,
		tempPixel.getB() - paramB, tempPixel.getA());
}

void Sub::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramB = params[2];
}

Pixel Greyscale::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	int avg = (tempPixel.getR() + tempPixel.getG() + tempPixel.getB()) / 3;
	return Pixel(avg,avg,avg,tempPixel.getA());
}

Pixel Invert::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	return Pixel(255-tempPixel.getR(),255-tempPixel.getG(),255-tempPixel.getB(),tempPixel.getA());
}

Pixel Median::operatePixel(Layer * l, int x, int y) const
{
	std::vector<Pixel> includedPixels;
	includedPixels.push_back((*l)[y][x]);
	bool notBottom = y > 0, notTop = y < Image::getImage()->getHeight() - 1;
	bool notLeft = x > 0, notRight = x < Image::getImage()->getWidth() - 1;
	if (notBottom) {
		includedPixels.push_back((*l)[y - 1][x]);
		if (notLeft)
			includedPixels.push_back((*l)[y - 1][x - 1]);
		if (notRight)
			includedPixels.push_back((*l)[y - 1][x + 1]);
	}
	if(notLeft)
		includedPixels.push_back((*l)[y][x - 1]);
	if (notRight)
		includedPixels.push_back((*l)[y][x + 1]);
	if (notTop) {
		includedPixels.push_back((*l)[y + 1][x]);
		if (notLeft)
			includedPixels.push_back((*l)[y + 1][x - 1]);
		if (notRight)
			includedPixels.push_back((*l)[y + 1][x + 1]);
	}
	int avgR = 0, avgG = 0, avgB = 0;
	for (Pixel p : includedPixels) {
		avgR += p.getR();
		avgG += p.getG();
		avgB += p.getB();
	}
	avgR /= includedPixels.size();
	avgG /= includedPixels.size();
	avgB /= includedPixels.size();
	return Pixel(avgR,avgG,avgB,includedPixels[0].getA());
}

bool CompositeOperation::aware() const
{
	return std::any_of(operations.begin(), operations.end(), [](Operation* o) {
		return o->aware();
	});
}

void CompositeOperation::operateLayer(Layer * l, const std::map<std::string, Selection*>& s) const
{
	for (Operation *o : operations) {
		o->operateLayer(l, s);
	}
}

Pixel Mul::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	return Pixel(tempPixel.getR() * paramR, tempPixel.getG() * paramG,
		tempPixel.getB() * paramB, tempPixel.getA());
}

void Mul::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramB = params[2];
}

Pixel Div::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	return Pixel(tempPixel.getR() / paramR, tempPixel.getG() / paramG,
		tempPixel.getB() / paramB, tempPixel.getA());
}

void Div::setParams(std::vector<double> params)
{
	if (params[0] == 0 || params[1] == 0 || params[2] == 0)
		throw BadInputException("Zero division");
	paramR = params[0], paramG = params[1], paramB = params[2];
}

Pixel Fill::operatePixel(Layer * l, int x, int y) const
{
	return Pixel(paramR, paramG, paramB, paramA);
}

void Fill::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramB = params[2], paramA = params[3] > 255? 255 : (params[3] < 0 ? 0 : params[3]);
}

Pixel BlackWhite::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	int avg = (tempPixel.getR() + tempPixel.getG() + tempPixel.getB()) / 3;
	avg = avg < 127 ? 0 : 255;
	return Pixel(avg, avg, avg, tempPixel.getA());
}

Pixel InverseDiv::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	return Pixel(paramR / tempPixel.getR(), paramG / tempPixel.getG() ,
		paramB / tempPixel.getB(), tempPixel.getA());
}

void InverseDiv::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramB = params[2];
}

Pixel InverseSub::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	return Pixel(paramR - tempPixel.getR(), paramG - tempPixel.getG(),
		paramB - tempPixel.getB(), tempPixel.getA());
}

void InverseSub::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramG = params[2];
}

Pixel Power::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	return Pixel(pow(tempPixel.getR(),paramR), pow(tempPixel.getG(), paramG),
		pow(tempPixel.getB(), paramB), tempPixel.getA());
}

void Power::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramB = params[2];
}

Pixel Log::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	//ako je neka komponenta 0 exception
	if (tempPixel.getR() == 0 || tempPixel.getG() == 0 || tempPixel.getB() == 0)
		return tempPixel;
	double logR = log(tempPixel.getR()) / log(paramR);
	double logG = log(tempPixel.getG()) / log(paramG);
	double logB = log(tempPixel.getB()) / log(paramB);
	return Pixel(logR, logG, logB, tempPixel.getA());
}

void Log::setParams(std::vector<double> params)
{
	if (params[0] < 0 || params[1] < 0 || params[2] < 0 || params[0] == 1 || params[1] == 1 || params[2] == 1)
		throw BadInputException("Invalid logarithm base entered");
	paramR = params[0], paramG = params[1], paramB = params[2];
}

Pixel Min::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	int newR = tempPixel.getR() > paramR ? paramR : tempPixel.getR();
	int newG = tempPixel.getG() > paramG ? paramG : tempPixel.getG();
	int newB = tempPixel.getB() > paramB ? paramB : tempPixel.getB();
	return Pixel(newR, newG, newB, tempPixel.getA());
}

void Min::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramB = params[2];
}

Pixel Max::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	int newR = tempPixel.getR() < paramR ? paramR : tempPixel.getR();
	int newG = tempPixel.getG() < paramG ? paramG : tempPixel.getG();
	int newB = tempPixel.getB() < paramB ? paramB : tempPixel.getB();
	return Pixel(newR, newG, newB, tempPixel.getA());
}

void Max::setParams(std::vector<double> params)
{
	paramR = params[0], paramG = params[1], paramB = params[2];
}

void Operation::addOperation(const std::string & name, Operation * o)
{
	if (operationMap.find(name) == operationMap.end()) {
		operationMap[name] = o;
	}
	else throw BadInputException("Operation with that name already exists");
}

void Operation::printOperations()
{
	for (std::pair<std::string, Operation*> p : operationMap)
		std::cout << p.second->getName() << ", ";
}

Operation * Operation::getOperation(const std::string& name)
{
	if (operationMap.find(name) != operationMap.end())
		return operationMap[name];
	else throw BadInputException("Operation does not exist");
}

Pixel Abs::operatePixel(Layer * l, int x, int y) const
{
	Pixel tempPixel = (*l)[y][x];
	int tempR = tempPixel.getR() < 0 ? -tempPixel.getR() : tempPixel.getR();
	int tempG = tempPixel.getG() < 0 ? -tempPixel.getG() : tempPixel.getG();
	int tempB = tempPixel.getB() < 0 ? -tempPixel.getB() : tempPixel.getB();
	return Pixel(tempR, tempG, tempB, tempPixel.getA());
}
