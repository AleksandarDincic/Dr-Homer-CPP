#include <iostream>
#include <string>
#include "Exceptions.h"
#include "Image.h"
#include "BMPFormatter.h"
#include "PAMFormatter.h"
#include "Operation.h"
#include "Selection.h"


std::vector<Rectangle> inputRects() {
	std::vector<Rectangle> rects;
	std::cout << "Enter the properties of each rectangle. Entering a non-positive number at any point will stop the input of rectangles" << std::endl;
	while (true) {
		int x, y, width, height;
		
		std::cout << "Enter the x-position of rectangle: ";
		std::cin >> x;
		if (x <= 0) break;
		
		std::cout << "Enter the y-position of rectangle: ";
		std::cin >> y;
		if (y <= 0) break;
		
		std::cout << "Enter the width of rectangle: ";
		std::cin >> width;
		if (width <= 0) break;

		std::cout << "Enter the height of rectangle: ";
		std::cin >> height;
		if (height <= 0) break;

		rects.push_back(Rectangle(x, y, width, height));
	}
	return rects;
}

int main() {
	std::string path, message = "";
	std::vector<Rectangle> rects;
	Image *image = nullptr;
	Operation *operation = nullptr;
	std::vector<double> params;
	double param;
	bool editMode = false;
	int choice;

	Formatter::addFormat("bmp", new BMPFormatter());
	Formatter::addFormat("pam", new BMPFormatter());
	Operation::addOperation(Add().getName(), new Add());
	Operation::addOperation(Sub().getName(), new Sub());
	Operation::addOperation(InverseSub().getName(), new InverseSub());
	Operation::addOperation(Mul().getName(), new Mul());
	Operation::addOperation(Div().getName(), new Div());
	Operation::addOperation(InverseDiv().getName(), new InverseDiv());
	Operation::addOperation(Power().getName(), new Power());
	Operation::addOperation(Log().getName(), new Log());
	Operation::addOperation(Abs().getName(), new Abs());
	Operation::addOperation(Min().getName(), new Min());
	Operation::addOperation(Max().getName(), new Max());
	Operation::addOperation(Invert().getName(), new Invert());
	Operation::addOperation(Greyscale().getName(), new Greyscale());
	Operation::addOperation(BlackWhite().getName(), new BlackWhite());
	Operation::addOperation(Median().getName(), new Median());
	Operation::addOperation(Fill().getName(), new Fill());


	while (true) {
		system("cls");

		std::cout << "=======Dr. Homer Image Editor=======" << std::endl;
		if (image)
			std::cout << *image << std::endl;

		std::cout << message << std::endl << std::endl;
		
		std::cout << "Select a command:" << std::endl;
		if (!editMode) {
			std::cout << "1. New project" << std::endl;
			std::cout << "2. Open project" << std::endl;
			std::cout << "3. Exit" << std::endl;
		}	
		else {
			std::cout << "1.  Add empty layer" << std::endl;
			std::cout << "2.  Add layer from image" << std::endl;
			std::cout << "3.  Delete layer" << std::endl;
			std::cout << "4.  Set layer opacity" << std::endl;
			std::cout << "5.  Set layer active" << std::endl;
			std::cout << "6.  Set layer visible" << std::endl;
			std::cout << "7.  Add selection" << std::endl;
			std::cout << "8.  Set selection active" << std::endl;
			std::cout << "9.  Delete selection" << std::endl;
			std::cout << "10. Add operation" << std::endl;
			std::cout << "99. Apply operations and export" << std::endl;
		}
		
		std::cin >> choice;
		if (!editMode) {
			switch (choice) {
			case 1:
				image = Image::getImage();
				editMode = true;
				break;
			case 2:
				message = "Nista to trenutno bato";
				break;
			case 3:
				exit(0);
				break;
			default:
				message = "Unknown command";
				break;
			}
		}
		else {
			switch (choice) {
			case 1:
				std::cout << "Enter the new layer's width: ";
				int width;
				std::cin >> width;
				std::cout << "Enter the new layer's height: ";
				int height;
				std::cin >> height;
				try {
				image->addLayer(width, height);
				message = "Layer added";
				}
				catch (BadInputException e) {
					message = e.getMessage();
				}
				break;
			case 2:
				std::cout << "Enter path to image :";
				std::cin >> path;
				try {
					image->addLayer(path);
					message = "Layer added";
				}
				catch(BadPathException e){
					message = e.getMessage();
				}
				catch (BadFormatException e) {
					message = e.getMessage();
				}
				break;
			case 3:
				std::cout << "Enter layer number :";
				std::cin >> choice;
				try {
					image->deleteLayer(choice - 1);
					message = "Layer deleted";
				}
				catch(BadInputException e){
					message = e.getMessage();
				}
				break;
			case 4:
				std::cout << "Enter layer number :";
				std::cin >> choice;
				int opacity;
				std::cout << "Enter layer opacity (0-100,will be clamped) :";
				std::cin >> opacity;
				try {
					image->setLayerOpacity(choice - 1, opacity);
					message = "Opacity changed";
				}
				catch(BadInputException e){
					message = e.getMessage();
				}
				break;
			case 5:
				std::cout << "Enter layer number :";
				std::cin >> choice;
				int active;
				std::cout << "Enter 0 for inactive, any other number for active:";
				std::cin >> active;
				try {
					image->setLayerActive(choice - 1, active);
					message = "Layer active state changed";
				}
				catch (BadInputException e) {
					message = e.getMessage();
				}
				break;
			case 6:
				std::cout << "Enter layer number :";
				std::cin >> choice;
				int visible;
				std::cout << "Enter 0 for invisible, any other number for visible:";
				std::cin >> visible;
				try {
					image->setLayerVisible(choice - 1, visible);
					message = "Layer visibility changed";
				}
				catch (BadInputException e) {
					message = e.getMessage();
				}
				break;
			case 7:
				std::cout << "Enter selection name :";
				std::cin >> path;
				try {
					image->addSelection(rects=inputRects(), path);
					message = "Selection added";
				}
				catch (BadInputException e) {
					message = e.getMessage();
				}
				break;
			case 8:
				std::cout << "Enter selection name :";
				std::cin >> path;
				std::cout << "Enter 0 for inactive, any other number for active:";
				std::cin >> choice;
				try {
					image->setSelectionActive(path, choice);
					message = "Selection active state changed";
				}
				catch (BadInputException e) {
					message = e.getMessage();
				}
				break;
			case 9:
				std::cout << "Enter selection name :";
				std::cin >> path;
				try {
					image->deleteSelection(path);
					message = "Selection deleted";
				}
				catch (BadInputException e) {
					message = e.getMessage();
				}
				break;
			case 10:
				std::cout << "Insert operation name. Available operations :" << std::endl;
				Operation::printOperations();
				std::cout << std::endl;
				std::cin >> path;
				try {
					operation = Operation::getOperation(path)->clone();
					std::cout << "Operation has " << operation->numOfParams() << " parameters" << std::endl;
					params.clear();
					for (int i = 0; i < operation->numOfParams(); i++) {
						std::cout << "Enter parameter " << (i + 1) << ": ";
						std::cin >> param;
						params.push_back(param);
					}
					operation->setParams(params);
					image->addOperation(operation);
				}
				catch(BadInputException e) {
					message = e.getMessage();
				}
				break;
			case 99:
				std::cout << "Insert export path: ";
				std::cin >> path;
				image->operate();
				image->Export(path);
				break;
			default:
				message = "Unknown command";
				break;
			}
		}
	}

	return 0;
}