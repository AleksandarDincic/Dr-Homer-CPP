#include <iostream>
#include <string>
#include "Menu.h"
#include "Formatter.h"
#include "Exceptions.h"


int main(int argc, const char* argv[]) {
	Menu::initialize();
	if (argc == 3) {
		try {
			Image *i = Image::getImage();
			i->addLayer(argv[1]);
			FUNFormatter formatter;
			CompositeOperation *o = formatter.load(argv[2]);
			i->addOperation(o);
			i->operate();
			i->Export(argv[1]);
		}
		catch (BadFormatException e) {
			std::cout << e.getMessage();
		}
		catch (BadInputException e) {
			std::cout << e.getMessage();
		}
		catch (BadPathException e) {
			std::cout << e.getMessage();
		}
		catch (...) {
			std::cout << "Unknown error";
		}
	}
	else {
		Menu m;
		m.start();
	}
	return 0;
}