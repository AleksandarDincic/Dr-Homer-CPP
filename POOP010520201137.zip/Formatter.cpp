#include "Formatter.h"

std::map<std::string, ImageFormatter*> ImageFormatter::formatMap;


void ImageFormatter::addFormat(std::string fileType, ImageFormatter * formatter)
{
	if (formatMap.find(fileType) == formatMap.end()) {
		formatMap[fileType] = formatter;
	}
	// u suprotnom exception
}

ImageFormatter * ImageFormatter::getFormatter(std::string fileType)
{
	if (formatMap.find(fileType) != formatMap.end())
		return formatMap[fileType];
	return nullptr;
}
