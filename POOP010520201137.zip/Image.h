#pragma once
#include <map>
#include "Layer.h"
#include "Operation.h"

class Selection;

class Image {
private:
	static Image* image;

	int width, height;
	bool unsaved;
	std::vector<Layer*> layers;
	std::vector<Operation*> operations;
	std::map<std::string, Selection*> selections;
	std::map<std::string, CompositeOperation*> compositeOperations;

	Image() : width(0), height(0), unsaved(true) {}

	void resize(Layer *l);
public:
	static Image* getImage();

	int getWidth() const { return width; }
	int getHeight() const { return height; }
	Layer& getLayer(int pos) const { return *layers[pos]; };
	CompositeOperation* getCompositeOperation(const std::string& name);


	void setLayerOpacity(int pos, int opacity);
	void setLayerActive(int pos, bool active);
	void setLayerVisible(int pos, bool visible);
	void setSelectionActive(const std::string& name, bool active);


	void addLayer(int width, int height);
	void addLayer(std::string path);
	void addOperation(Operation* operation) { operations.push_back(operation); }
	void addSelection(std::vector<Rectangle>& rects, std::string name);
	void operate();
	void deleteLayer(int pos);
	void deleteSelection(const std::string& name);
	void clearOperations();
	void saveCompositeOperation(const std::string& name);
	void deleteCompositeOperation(const std::string& name);
	void Export(std::string path);
	Pixel getPixel(int width, int height);
	friend std::ostream& operator<<(std::ostream& o, const Image& i);
};