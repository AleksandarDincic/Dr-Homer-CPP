#pragma once
#include <map>
#include "Layer.h"
#include "rapidxml.hpp"

class ImageFormatter {
private:
	static std::map<std::string, ImageFormatter*> formatMap;

public:
	static void addFormat(std::string fileType, ImageFormatter *formatter);
	static ImageFormatter* getFormatter(std::string fileType);

	virtual Layer* load(std::string path)const = 0;
	virtual void save(std::string path) const = 0;

};

class BMPFormatter : public ImageFormatter {
public:
	Layer* load(std::string path) const override;
	void save(std::string path) const override;

};

class PAMFormatter : public ImageFormatter {
public:
	Layer* load(std::string path) const override;
	void save(std::string path) const override;

};

class CompositeOperation;

class OperationFormatter {
public:
	virtual CompositeOperation* load(const std::string& path, bool override = true) = 0;
	virtual void save(CompositeOperation *operation, const std::string& path) = 0;
};

class FUNFormatter : public OperationFormatter{
private:
	rapidxml::xml_document<> doc;
public:
	CompositeOperation* load(const std::string& path, bool override = true) override;
	void save(CompositeOperation *operation, const std::string& path) override;
};