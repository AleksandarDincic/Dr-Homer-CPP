#pragma once
#include <iostream>
#include "Image.h"

class Menu {
private:
	static	bool initialized; 
	
	bool running, editMode;
	std::string message;
	Image* image;
	
	void initImage() { image = Image::getImage(); editMode = true; }
	
	void refreshMenu();
	void addLayer();
	void deleteLayer();
	void setLayerOpacity();
	void setLayerActive();
	void setLayerVisible();
	void addSelection();
	void setSelectionActive();
	void deleteSelection();
	void addOperation();
	std::vector<Rectangle> inputRects();
	void addLayerFromPath();
	void inputChoice();
	void clearOperations();
	void operate();
	void saveCompositeOperation();
public:
	static void initialize();

	void start();
	Menu() : running(true), editMode(false), message(""), image(nullptr) {}
};