#pragma once

class Rectangle {
private:
	int x, y, width, height;
public:
	Rectangle(int x, int y, int width, int height) :
		x(x), y(y), width(width), height(height) {}
	bool inRect(int x, int y) const {
		return (x >= this->x && x <= this->x + width) && (y <= this->y && y >= this->y - height);
	}
};